const madisines = [
  {
    name:
    "Daraprin",  
                 alternative: 
    "Daramin",
                 manufacturer:
     "undefined",
       price: "Rs. 250",
                image: 
  "https://dwaey.com/medrg/upload/1723992724.png",
  button:"https://www.1mg.com/drugs/daramin-25mg-tablet-201707",
                  },
       
       {
         name: "Zytiga",
         alternative: "Mytera",
         manufacturer: "Mylan Pharma",
         price: "Rs. 15000",
         image: "https://onemg.gumlet.io/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/cx456kwzkuscoxk4bl4d.jpg?format=auto",
         button: "https://www.apollopharmacy.in/medicine/mytera-250mg-tablet-120-s"
         
       } , 
       {
         name: "Glivec",
         alternative: "Veenat",
         manufacturer: "Natco Pharma",
         price: "Rs. 1500",
         image: "https://onemg.gumlet.io/l_watermark_346,w_690,h_700/a_ignore,w_690,h_700,c_pad,q_auto,f_auto/a5f53d8d234d45a695d7c6f59707c652.jpg",
         button: "https://www.1mg.com/drugs/veenat-400-tablet-14360?srsltid=AfmBOoozkKt5QjS2GyIzsogcO_R2FtOGzBoVQFn3fwsoCUwofa590wBc&wpsrc=Google+Organic+Search",
       },
       {
         name: "Paracetamol",
         alternative: "Crocin",
         manufacturer:      "Micro labs",
         price: "Rs. 20-30 per 10 tablet",
         image: "https://5.imimg.com/data5/SELLER/Default/2022/9/QR/AF/MV/69966959/paracip-paracetamol-650-tablet.jpg",
         button: "https://www.1mg.com/search/all?filter=true&name=Paracetamol",
       },
       {
         name:"Combiflam",
         alternative:"Ibuprofen",
         manufacturer:"Abbott",
         price:"Rs. 20-30 per 10 tablets",
         image:"https://images.apollo247.in/pub/media/catalog/product/c/o/combiflam_tablet_20_s-1.png?tr=q-80,f-webp,w-400,dpr-3,c-at_max%201200w",
         button:"https://www.1mg.com/search/all?filter=true&name=Combiflam"
       },
        {
          name: "Disprin",
          alternative: "Ecosprin",
          manufacturer: "Reckitt Benckiser",
          price:"Rs. 10-20 for 10 tablets",
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfABbWyZY3yywBJtf60mpv4GyfpwTHVj5yGA&s",
          button: "https://www.1mg.com/search/all?filter=true&name=Ecosprin",
        },
        {
          name:"ORS",
          alternative: "Electral",
          manufacturer: "FDC Ltd",
          price: "Rs. 15-25 per sachet",
          image:"https://cdn01.pharmeasy.in/dam/products_otc/W81928/prolyte-ors-orange-drink-sachet-21-gm-2-1654249497.jpg",
          button: "https://www.1mg.com/search/all?name=ors",
          
        },
         
         {
          name: "Vicks Vaporub",
          alternative:"Zandu Balm",
          manufacturer:"Emami",
          price:"Rs. 40-60 for 25g",
          image:"https://cdn01.pharmeasy.in/dam/products_otc/181140/vicks-vaporub-50ml-relief-from-cold-cough-headache-and-body-pain-2-1677525570.jpg",
          button: "https://www.1mg.com/search/all?name=Vicks%20Vaporub&st=vivks%20vaporup&sl=Vicks%20Vapor,Vicks%20Vaporub&s=Vicks%20Vaporub",
         },
         {
           name:"Digene",
           alternative:"ENO",
           manufacturer:"GlaxoSmithKline",
           price:"Rs. 20-40 for 10 tablets or Rs. 60-80 for 200 ml bottle",
           image:"https://i-cf65.ch-static.com/content/dam/cf-consumer-healthcare/nutrition-eno/en_IN/home/mobile/homepage-header-carousal-1-v3_mobile.jpg?auto=format",
           button:` 
             https://www.1mg.com/search/all?name=digene`,
         },
         {
           
           name:"Strepsils",
           alternative:"Vicks",
           manufacturer:"Procter & Gamble",
           price:"Rs. 30-50 for a pack of 8-10 tablets",
           image:"https://images.ctfassets.net/umpxkz97ty8t/4tjmmu8xgFdItABWjhpWTA/88afdcd6055df8b4fac3fdea0098dfa5/VCD4-Packs.png",
           button:"https://www.1mg.com/categories/featured/top-brands/strepsils-884",
         },
         {
           name:"Benadryl",
           alternative:"Corex",
           manufacturer:"Pfizer",
           price:"Rs. 50-80 per bottle (100 ml)",
           image:"https://images.apollo247.in/pub/media/catalog/product/b/e/ben0053_1.jpg?tr=q-80,f-webp,w-400,dpr-3,c-at_max%201200w",
           button:"https://www.1mg.com/search/all?filter=true&name=Benadryl",
         },
         
         {
           name:"Augmentin 1000 Duo Tablet",
           alternative:"Clavam",
           manufacturer:"Alkem Laboratories",
           price:"Rs. 193",
           image:"https://onemg.gumlet.io/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/bodminug3xmfcubbrdix.jpg?format=auto",
           button:"https://www.1mg.com/drugs/augmentin-1000-duo-tablet-163191",
         },
         {
           name:"Crestor",
           alternative:"Rosuvas",
           manufacturer:"Astrazeneca",
           price:"Rs. 277",
           image:"https://5.imimg.com/data5/SELLER/Default/2024/6/425035920/PX/LR/WN/147700842/rosuvas-10-mg-tablet1-500x500.jpg",
           button:"https://www.1mg.com/drugs/rosuvas-10-tablet-113791",
         },
         {
           
           name:"lantus",
           alternative:"basalog",
           manufacturer:"bicon",
           price:"Rs. 481",
           image:"https://onemg.gumlet.io/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_aut&& o,f_auto/0c379a5816da4e63b74cd6889b2d382a.jpg?format=auto",
           button:"https://www.1mg.com/drugs/basalog-100iu-ml-refill-cartridge-164232",
         
         },
         
         {
           
           name:"Tamiflu",
           alternative:"Fluvir",
           manufacturer:"Hetero Drugs Ltd",
           price:"Rs.447",
           image:"https://images.apollo247.in/pub/media/catalog/product/f/l/flu0174.jpg?tr=q-80,f-webp,w-400,dpr-3,c-at_max%201200w",
           button:"https://www.1mg.com/drugs/fluvir-75mg-capsule-25088",
         
         },
         {
           
           name:"Eliquis",
           alternative:"Apigat",
           manufacturer:"Nacto pharma Ltd",
           price:"Rs.533",
           image:"https://www.practostatic.com/practopedia-images/v3/res-750/apigat-2-5-mg-tablet-30-s_15fa3947-9fad-47f2-bbed-8d5f500e66e9.JPG",
           button:"https://www.1mg.com/drugs/apigat-5-tablet-540276",
         
         },
      
       ];
       
const container = document.getElementById("madisinfinder");
const searchinput = document.getElementById("search-input");

function displayContainer(data) {
  container.innerHTML = ''; // Reset container
  data.forEach(med => {
    const card = `
      <div class="card">
        <img src="${med.image}" alt="${med.name}">
        <h3>${med.name}</h3>
        <p><b>Alternative:</b> ${med.alternative}</p>
        <p><b>Manufacturer:</b> ${med.manufacturer !== "undefined" ? med.manufacturer : "Not Specified"}</p>
        <p><b>Price:</b> ${med.price}</p>
        <button class="info-btn">More information</button>
      </div>
    `;
    const divElement = document.createElement('div');
    divElement.innerHTML = card;

    const button = divElement.querySelector(".info-btn");
    button.addEventListener("click", () => {
      window.open(med.button, "_blank"); // Open link in a new tab
    });

    container.appendChild(divElement); // Append card to the container
  });
}

displayContainer(madisines);

searchinput.addEventListener('input', () => {
  const keyword = searchinput.value.toLowerCase();
  const filtered = madisines.filter(med => med.name.toLowerCase().includes(keyword));
  displayContainer(filtered);
});